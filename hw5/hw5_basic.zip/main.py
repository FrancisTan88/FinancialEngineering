from models import MonteCarlo, BinomialTree
import numpy as np


def read_input():
    S_t = float(input())
    K = float(input())
    r = float(input())
    q = float(input())
    sigma = float(input())
    t = float(input())
    T_minus_t = float(input())
    M = int(input())
    n = int(input())
    S_ave_t = float(input())
    Sim_n = int(input())
    Rep_n = int(input())
    return S_t, K, r, q, sigma, t, T_minus_t, M, n, S_ave_t, Sim_n, Rep_n



if __name__ == "__main__":
    S_t, K, r, q, sigma, t, T_minus_t, M, n, S_ave_t, Sim_n, Rep_n = read_input()
    
    mc = MonteCarlo(S_t, K, r, q, sigma, t, T_minus_t, M, n, S_ave_t, Sim_n, Rep_n)
    mean, std = mc.main()
    print(f"\nMonte Carlo:\n(1)European calls = {round(mean, 4)}\n(2)Confidence Interval = [{round(mean-2*std, 4)}, {round(mean+2*std, 4)}]")
    
    bt = BinomialTree(S_t, K, r, q, sigma, t, T_minus_t, M, n, S_ave_t, Sim_n, Rep_n)
    euro_calls, usa_calls = bt.main()
    print(f"\nBinomial Tree:\n(1)European calls = {round(euro_calls, 4)}\n(2)American calls = {round(usa_calls, 4)}")



