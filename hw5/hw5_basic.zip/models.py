import numpy as np


class MonteCarlo:
    def __init__(self, St, K, r, q, sigma, t, T_minus_t, M, n, S_ave_t, nums_sim, nums_rep) -> None:
        self.St = St
        self.K = K
        self.r = r
        self.q = q
        self.sigma = sigma
        self.t = t
        self.T_minus_t = T_minus_t
        self.M = M
        self.n = n
        self.S_ave_t = S_ave_t
        self.nums_sim = nums_sim
        self.nums_rep = nums_rep

        self.dt = self.T_minus_t / self.n
        self.periods_before_t = 1 + self.t/self.dt  # include t itself
        self.total_price_before_t = self.periods_before_t * self.S_ave_t  # include St itself

    # this is for one of reps (i.e. 10000 paths) -> List[avg stock price over whole period]
    def cal_avg(self):
        sps = np.zeros((self.nums_sim, self.n+2))
        rands = np.random.normal(0, 1, size=(self.nums_sim, self.n+2))
        sps[:, 0] = self.S_ave_t * self.periods_before_t - self.St
        sps[:, 1] = self.St
        std = self.sigma * (self.dt**0.5)
        for col in range(2, self.n+2):
            sps[:, col] = np.exp((np.log(sps[:, col-1]) + self.dt*(self.r - self.q - (self.sigma**2)/2)) + \
                            rands[:, col] * std)
        return np.sum(sps, axis=1) / (self.periods_before_t + self.n)

    # payoff for euro calls -> float
    def cal_payoff(self, avgs):
        payoffs = np.where(avgs > self.K, avgs - self.K, 0)
        return np.mean(payoffs) * np.exp(-self.r*(self.T_minus_t))

    def main(self):
        reps = []
        for _ in range(self.nums_rep):
            avgs = self.cal_avg()
            reps.append(self.cal_payoff(avgs))
        reps = np.array(reps)
        return np.mean(reps), np.std(reps)


class BinomialTree(MonteCarlo):
    def __init__(self, St, K, r, q, sigma, t, T_minus_t, M, n, S_ave_t, nums_sim, nums_rep) -> None:
        super().__init__(St, K, r, q, sigma, t, T_minus_t, M, n, S_ave_t, nums_sim, nums_rep)

        self.u = np.exp(self.sigma * (self.dt**0.5))
        self.d = 1 / self.u
        self.p = (np.exp((self.r - self.q) * self.dt) - self.d) / (self.u - self.d)

    def create_nodes(self):
        nodes = np.zeros((self.n+1, self.n+1, self.M+1, 2))  # 4D array
        for j in range(self.n+1):
            for i in range(j+1):
                # avg_lst = []
                # calculate A_max, A_min
                A_max = (self.St + self.St * self.u * ((1-self.u**(j-i)) / (1-self.u)) + 
                            self.St * (self.u**(j-i)) * self.d * ((1-self.d**i) / (1-self.d)) +
                                (self.total_price_before_t - self.St)) / (self.periods_before_t + j)
                A_min = (self.St + self.St * self.d * ((1-self.d**i) / (1-self.d)) + 
                            self.St * (self.d**i) * self.u * ((1-self.u**(j-i)) / (1-self.u)) +
                                (self.total_price_before_t - self.St)) / (self.periods_before_t + j)
                # calculate representative avg price
                for k in range(self.M+1):
                    # avg_lst.append([(self.M-k)/self.M * A_max + k/self.M * A_min, -1])
                    nodes[i][j][k][0] = (self.M-k)/self.M * A_max + k/self.M * A_min
                    nodes[i][j][k][1] = -1

        return nodes
    
    # for european calls
    def backward_induction_euro(self, nodes):
        # if A equals one of values in list, just return it.
        # otherwise, use "linear interpolation" with the two values that enclose the A. 
        def sequential_search(avg_lst, A):
            if A >= avg_lst[0][0]:
                return avg_lst[0][1]
            elif A <= avg_lst[-1][0]:
                return avg_lst[-1][1]
            for k in range(1, len(avg_lst)):
                if A == avg_lst[k][0]:
                    return avg_lst[k][1]
                elif A > avg_lst[k][0]:
                    weight = (avg_lst[k-1][0] - A) / (avg_lst[k-1][0] - avg_lst[k][0])
                    return weight*avg_lst[k][1] + (1-weight)*avg_lst[k-1][1]
            raise ValueError("Something goes wrong with the sequential search function !!!")

        # calculate the payoffs of the last column
        for row in range(self.n+1):
            nodes[row][-1] = np.array(nodes[row][-1])
            nodes[row][-1][:, 1] = np.where(nodes[row][-1][:, 0] > self.K, 
                                            nodes[row][-1][:, 0] - self.K, 0)
        # backward induction
        for col in range(self.n-1, -1, -1):
            for row in range(col+1):
                for k in range(len(nodes[row][col])):
                    Au = ((self.periods_before_t + col) * nodes[row][col][k][0] + self.St * (self.u**(col+1-row)) * (self.d**row)) / \
                            (self.periods_before_t + col + 1)
                    Ad = ((self.periods_before_t + col) * nodes[row][col][k][0] + self.St * (self.u**(col-row)) * (self.d**(row+1))) / \
                            (self.periods_before_t + col + 1)
                    # search up node
                    Cu = sequential_search(nodes[row][col+1], Au)
                    Cd = sequential_search(nodes[row+1][col+1], Ad)

                    nodes[row][col][k][1] = np.exp(-self.r*self.dt) * (self.p*Cu + (1-self.p)*Cd)

        return nodes[0][0][0][1]

    # for American calls: the only diff is to consider the "early exercise"
    def backward_induction_usa(self, nodes):
        # if A equals one of values in list, just return it.
        # otherwise, use "linear interpolation" with the two values that enclose the A. 
        def sequential_search(avg_lst, A):
            if A >= avg_lst[0][0]:
                return avg_lst[0][1]
            elif A <= avg_lst[-1][0]:
                return avg_lst[-1][1]
            for k in range(1, len(avg_lst)):
                if A == avg_lst[k][0]:
                    return avg_lst[k][1]
                elif A > avg_lst[k][0]:
                    weight = (avg_lst[k-1][0] - A) / (avg_lst[k-1][0] - avg_lst[k][0])
                    return weight*avg_lst[k][1] + (1-weight)*avg_lst[k-1][1]
            raise ValueError("Something goes wrong with the sequential search function !!!")

        # calculate the payoffs of the last column
        for row in range(self.n+1):
            nodes[row][-1] = np.array(nodes[row][-1])
            nodes[row][-1][:, 1] = np.where(nodes[row][-1][:, 0] > self.K, 
                                            nodes[row][-1][:, 0] - self.K, 0)
        # backward induction
        for col in range(self.n-1, -1, -1):
            for row in range(col+1):
                for k in range(len(nodes[row][col])):
                    Au = ((self.periods_before_t + col) * nodes[row][col][k][0] + self.St * (self.u**(col+1-row)) * (self.d**row)) / \
                            (self.periods_before_t + col + 1)
                    Ad = ((self.periods_before_t + col) * nodes[row][col][k][0] + self.St * (self.u**(col-row)) * (self.d**(row+1))) / \
                            (self.periods_before_t + col + 1)
                    # search up node
                    Cu = sequential_search(nodes[row][col+1], Au)
                    Cd = sequential_search(nodes[row+1][col+1], Ad)

                    # payoff func
                    factor = np.exp(-self.r*self.dt) * (self.p*Cu + (1-self.p)*Cd)
                    early_exercise = nodes[row][col][k][0] - self.K
                    nodes[row][col][k][1] = max(early_exercise, factor)

        return nodes[0][0][0][1]

    def main(self):
        nodes = self.create_nodes()
        calls_euro = self.backward_induction_euro(nodes)
        calls_usa = self.backward_induction_usa(nodes)
        return calls_euro, calls_usa

